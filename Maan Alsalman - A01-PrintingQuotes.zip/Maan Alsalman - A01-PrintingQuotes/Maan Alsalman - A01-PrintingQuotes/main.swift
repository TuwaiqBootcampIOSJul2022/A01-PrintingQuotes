print("What is the qoute?")
var qoute = readLine()

print("Who said it?")
var name = readLine()

print( name! + " says, \"" + qoute! + "\"")
